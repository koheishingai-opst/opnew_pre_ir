var fs = require('fs');
var path = require('path');

var gulp = require('gulp'),
    gutil = require('gulp-util');
// gulp plugins
var sass = require('gulp-sass');
var autoprefixer = require('gulp-autoprefixer');
var minify = require('gulp-minify');
var sass = require('gulp-sass');
var compass = require('gulp-compass'),
    minifyCSS = require('gulp-minify-css');
var concat = require('gulp-concat');
var jsmin = require('gulp-jsmin'),
    rename = require('gulp-rename');
var livereload = require('gulp-livereload'),
    http = require('http');
    // ecstatic = require('ecstatic');
var plumber = require('gulp-plumber');
var plugins = require('gulp-load-plugins')();
var runSequence = require('run-sequence');

// var pkg = require('./package.json');
// var dirs = pkg['h5bp-configs'].directories;

gulp.task('build', function (done) {
  // 各ソースをminify
  var targets = ["controllers", "models", "utils", "templates", "filters", "libs", "databases"];
  targets.forEach(function(val) {
    js_min_task(["./assets/js/" + val + "/*.js", "./assets/js/**/" + val + "/*.js"], "./www/js/min/" + val + ".min.js");
  })
});

gulp.task('default', ['build']);

// ---------------------------------------------------------------------
// | Main tasks                                                        |
// ---------------------------------------------------------------------

gulp.task('watch:task', function(){
  gulp.watch('./assets/sass/*.sass', ['sass'])
  gulp.watch('./assets/js/*.js', ['js'])
});

gulp.task('cordova', ['cordova:serve', 'source:watch:minify', 'cordova:watch', 'watch:task']);

// ---------------------------------------------------------------------
// | Sub tasks                                                         |
// ---------------------------------------------------------------------

// Sass task
gulp.task('sass', function() {
  var stream = gulp.src('./assets/sass/*.sass') // 対象ファイル達
    .pipe(plumber())
    .pipe(compass({
      config_file: './config.rb',
      css: './www/css',
      sass: './assets/sass',
    })) // Compass
    .pipe(autoprefixer()) // Vendor prefix 最適化
    //.pipe(minifyCSS())    // css 圧縮
    .pipe(gulp.dest('./www/css'));

  console.log('sass compiled!');

  return stream;
})

gulp.task('js', function() {

  var target_dirs = [
    "controllers",
    "models",
    "utils",
    "templates",
    "filters",
    "libs",
    "databases"];
  target_dirs.forEach(function(val) {
    js_min_task([
        "./assets/js/" + val + "/*.js",
        "./assets/js/**/" + val + "/*.js"
      ],
      "./www/js/" + val + ".js");
  });

  var stream = gulp.src("./assets/js/*.js").pipe(gulp.dest('./www/js/'));
  console.log('js compiled!');

  return stream;
});

/**
 * Source watch to minify
 * @param  {[type]} 'cordova:watch' [description]
 * @param  {[type]} function(       [description]
 * @return {[type]}                 [description]
 */
gulp.task('source:watch:minify', function() {

  gulp.watch('assets/js/**/*.{js}', function(file) {
    // 各ソースをminify
    var targets = ["controllers", "models", "utils", "templates", "filters", "libs", "databases"];
    targets.forEach(function(val) {
      if(file.path.indexOf(val) > -1) {
        js_min_task(["./assets/js/" + val + "/*.js", "./assets/js/**/" + val + "/*.js"], "./www/js/min/" + val + ".min.js");
      }
    })
  })
});

// Cordova live reload
gulp.task('monaca:watch', function() {

  gulp.watch('assets/sass/*.sass', ['sass'])
  gulp.watch('./assets/js/**/*.js', ['js'])
});

// Cordova live reload
gulp.task('cordova:watch', function() {

  //gulp.watch('www/**/*.{js,html,css}', ['copy']);
  gulp.watch('www/**/*.{js,html,css,png,jpg,sass}', function(file) {

    gulp.src(file.path, { "base": "./www/"})
      .pipe(gulp.dest('platforms/ios/www/'))
      .pipe(livereload());
  });
});

gulp.task('copy', function() {
    gulp.src('www/**/*.{js,html,css}')
        .pipe(gulp.dest('platforms/ios/www/'))
        .pipe(livereload());
});

gulp.task('cordova:serve', function() {
  var port = 8090;
  var url = "http://localhost:" + port + "/";
  http.createServer(ecstatic({
    root: "platforms",
    cache: 0
  })).listen(port);

  gutil.log(gutil.colors.blue("HTTP server listening on " + port));
});

/**
 * jsを圧縮して特定のディレクトリに配置
 * @param  {[type]} 'js:min'        [description]
 * @param array files []
 * @param string outputPath outputPath sample: "./www/js/models.min.js"
 */
var js_min_task = function(files, outputPath) {
  var output = /(.+\/)(.+)/.exec(outputPath);
  var concatName = output[2]; // 結合したファイル名
  var outputDir = output[1];  // 出力先ディレクトリ

  // DBファイルの場合は圧縮しない
  if(outputPath.indexOf('databases') > -1) {
    gulp.src(files)
      .pipe(concat(concatName))
      .pipe(gulp.dest(outputDir));
  } else {
    gulp.src(files)
      .pipe(concat(concatName))
      // .pipe(jsmin())
      .pipe(gulp.dest(outputDir));
  }
}
