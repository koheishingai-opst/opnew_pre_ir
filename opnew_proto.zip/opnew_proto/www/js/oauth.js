var $oauthWrap = document.getElementById("oauth_wrap");
var $oauthTxt = document.getElementById("oauth_txt");
var $oauthBtn = document.getElementById("oauth_btn");
var $oauth = document.getElementById("oauth");
var $menuSetting = document.getElementById("menu_setting");
var $localStorage = window.localStorage;

function EncodeHTMLForm(data) {
    var params = [];

    for(var name in data) {
        var value = data[name];
        var param = encodeURIComponent(name) + '=' + encodeURIComponent(value);
        params.push(param);
    }

    return params.join('&').replace(/%20/g, '+');
}

function oauth($email) {
    var data = { email: $email };
    var xmlHttpRequest = new XMLHttpRequest();

    xmlHttpRequest.onreadystatechange = function() {
        console.log('Oauth End - ' + this.status);
        $oauthBtn.style.display = "none";
        $oauth.setAttribute("onclick", "signOut()");
    };

    xmlHttpRequest.open('POST', 'http://'+ window.SERVER_HOST +'/user/oauth', true);
    xmlHttpRequest.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xmlHttpRequest.send(EncodeHTMLForm(data));
};

function signOut() {
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(function () {
      $localStorage.gmailLogin = ""
      $localStorage.gmailEmail = "";
      $localStorage.gmailFirstName = "";
      $localStorage.gmailLastName = "";
      $localStorage.gmailProfilePicture = "";
      $oauthBtn.style.display = "block";
      $oauth.removeAttribute("onClick");
      window.location.href = "index.html";     
    });
}

function onSignIn(googleUser) {
    var data = googleUser.getBasicProfile();
    if ($localStorage.gmailLogin == "true") {
      oauth($localStorage.gmailEmail);
    } else {
      $localStorage.gmailLogin = "true";
      $localStorage.gmailEmail = data.U3;
      $localStorage.gmailFirstName = data.ofa;
      $localStorage.gmailLastName = data.wea;
      $localStorage.gmailProfilePicture = data.Paa;
      window.location.href = 'index.html';
    } 
}

if ($localStorage.gmailLogin == "true") {
    $oauthBtn.style.display = "none";
    $oauth.setAttribute("onclick", "signOut()");
    $oauthTxt.innerText = "ログアウト";
    $menuSetting.style.display = "block";
} else {
    $oauthBtn.style.display = "block";
    $oauth.removeAttribute("onClick");
    $oauthTxt.innerText = "ログイン";
    $menuSetting.style.display = "none";
}