var $oauthWrap = document.getElementById("oauth_wrap");
var $oauthTxt = document.getElementById("oauth_txt");
var $menuSetting = document.getElementById("menu_setting");
var $oauth = document.getElementById("oauth");
var $body = $("body");

function EncodeHTMLForm(data) {
    var params = [];

    for(var name in data) {
        var value = data[name];
        var param = encodeURIComponent(name) + '=' + encodeURIComponent(value);
        params.push(param);
    }

    return params.join('&').replace(/%20/g, '+');
}

function oauth($email) {
    var data = { email: $email };
    var xmlHttpRequest = new XMLHttpRequest();

    xmlHttpRequest.onreadystatechange = function() {
        console.log('Oauth End - ' + this.status);
        $body.fadeIn();
        $oauth.setAttribute("onclick", "disconnectUser()");
        $menuSetting.style.display = "block";
    };

    xmlHttpRequest.open('POST', 'http://'+ window.SERVER_HOST +'/user/oauth', true);
    xmlHttpRequest.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xmlHttpRequest.send(EncodeHTMLForm(data));
};

var googleapi = {
    authorize: function(options) {
        var deferred = $.Deferred();
        var authUrl = 'https://accounts.google.com/o/oauth2/auth?' + $.param({
            client_id: options.client_id,
            redirect_uri: options.redirect_uri,
            response_type: 'code',
            scope: options.scope
        });

        var authWindow = window.open(authUrl, '_blank', 'location=no,toolbar=no');
        $(authWindow).on('loadstart', function(e) {
            var url = e.originalEvent.url;
            var code = /\?code=(.+)$/.exec(url);
            var error = /\?error=(.+)$/.exec(url);

            if (code || error) {
                authWindow.close();
            }
            
            if (code) {
                $.post('https://accounts.google.com/o/oauth2/token', {
                    code: code[1],
                    client_id: options.client_id,
                    client_secret: options.client_secret,
                    redirect_uri: options.redirect_uri,
                    grant_type: 'authorization_code'
                }).done(function(data) {
                    deferred.resolve(data);
                }).fail(function(response) {
                    $(".loading").fadeOut();
                    $(".container").fadeIn();
                    deferred.reject(response.responseJSON);
                });
            } else if (error) {
                $(".loading").fadeOut();
                $(".container").fadeIn();
                deferred.reject({
                    error: error[1]
                });
            }
        });

        return deferred.promise();
    }
};
var accessToken;
var UserData = null;

function callGoogle() {
    $body.fadeOut();
    googleapi.authorize({
        client_id: '632080702527-je7htc0n344nohgdbjrqdnu71ldgoggc.apps.googleusercontent.com',
        client_secret: 'XYow_tyz3R8uNZSVlGAle3Fb',
        redirect_uri: 'http://localhost',
        scope: 'https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email'
    }).done(function(data) {
        getDataProfile(data.access_token);
    });
}

function getDataProfile(token) {
    var term = null;
    $.ajax({
        url: 'https://www.googleapis.com/oauth2/v1/userinfo?alt=json&access_token=' + token,
        type: 'GET',
        data: term,
        dataType: 'json',
        error: function(jqXHR, text_status, strError) {},
        success: function(data) {
            if (localStorage.gmailLogin == "true") {
                oauth(localStorage.gmailEmail);
            } else {
                localStorage.gmailLogin = "true";
                localStorage.gmailEmail = data.email;
                localStorage.gmailFirstName = data.given_name;
                localStorage.gmailLastName = data.family_name;
                localStorage.gmailProfilePicture = data.picture;
                localStorage.accessToken = data.access_token;
                $oauth.setAttribute("onclick", "disconnectUser()");
                location.reload();
            } 
        }
    });
}

function disconnectUser() {

    location.hash = "/app/list";

    var revokeUrl = 'https://accounts.google.com/o/oauth2/revoke?token=' + localStorage.accessToken;
    
    function reset() {
        localStorage.gmailLogin = "";
        localStorage.gmailEmail = "";
        localStorage.gmailFirstName = "";
        localStorage.gmailLastName = "";
        localStorage.gmailProfilePicture = "";
        localStorage.accessToken = "";
        $oauth.setAttribute("onClick", "callGoogle()");
        $body.fadeOut();
        location.reload();    
    }
    
    $.ajax({
        type: 'GET',
        url: revokeUrl,
        async: false,
        contentType: "application/json",
        dataType: 'jsonp',
        success: function(nullResponse) {
            reset();
        },
        error: function(e) {
            reset();
        }
    });
}

if (localStorage.gmailLogin == "true") {
    $oauthTxt.innerText = "ログアウト";
    oauth(localStorage.gmailEmail);
} else {
    $oauth.setAttribute("onClick", "callGoogle()");
    $oauthTxt.innerText = "ログイン";
    $menuSetting.style.display = "none";
}