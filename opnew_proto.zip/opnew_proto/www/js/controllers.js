opnew.controller('AppCtrl', function($scope, $ionicModal, $timeout, $http) {
    var $head = document.getElementsByTagName("head")[0];

    if (!window.cordova) {
        window.SERVER_HOST = "localhost";
        var $body = document.getElementsByTagName("body")[0];
        var $title = document.getElementsByTagName("title")[0];
        var $oauth = document.getElementById("oauth");
        var $oauthWrap = document.getElementById("oauth_wrap");
        
        var $metaScope = document.createElement("meta");
        $metaScope.name = "google-signin-scope";
        $metaScope.content = "profile email";
        
        var $metaClientId = document.createElement("meta");
        $metaClientId.name = "google-signin-client_id";
        $metaClientId.content = "632080702527-je7htc0n344nohgdbjrqdnu71ldgoggc.apps.googleusercontent.com";
        
        var $scriptPlatform = document.createElement("script");
        $scriptPlatform.src = "https://apis.google.com/js/platform.js";
        
        var $scriptOnSignIn = document.createElement("script");
        $scriptOnSignIn.src = "js/oauth.js";
        
        var $oauthBtn = document.createElement("div");
        
        $oauth.removeAttribute("ng-click");
        $oauthBtn.id = "oauth_btn";
        $oauthBtn.classList.add("g-signin2");
        $oauthBtn.setAttribute("data-onsuccess", "onSignIn");
        $oauthBtn.setAttribute("data-theme", "dark");
        
        $oauthWrap.appendChild($oauthBtn);
        $head.insertBefore($metaScope, $title);
        $head.insertBefore($metaClientId, $title);
        $head.appendChild($scriptPlatform);
        $body.appendChild($scriptOnSignIn);
    } else {
        window.SERVER_HOST = "news.opst.co.jp"; // 社内サーバー
        var $scriptJquery = document.createElement("script");
        $scriptJquery.src = "lib/jquery.min.js";
        $head.appendChild($scriptJquery);
        var $scriptLogin = document.createElement("script");
        $scriptLogin.src = "js/mobile_oauth.js";
        $head.appendChild($scriptLogin);
    }
});

opnew.controller('ArticleCtrl', function($scope, $ionicModal, $stateParams, $q, $http) {

    var $hash = $stateParams.id;
    var now = new Date();
    var $today = now.toISOString().slice(0,10).replace(/-/g,"");

    function formatArticleInfo(data) {
        for (var i in data) {
            var date = parseInt(data[i]["date"]);
            date = new Date(date / 10000, date % 10000 / 100, date % 100);
            var year = date.getFullYear();
            var month = date.getMonth();
            var day = date.getDate();
            $scope.date = year + "年" + month + "月" + day + "日"; 
            $scope.tag = '';
            $scope.title = unescape(data[i]["title"].split("\\").join("%"));
        }
    }

    function getArticleInfo($hash) {
        return $q(function(resolve, reject) {    
            $http({
                method: 'GET',
                url: 'http://' + window.SERVER_HOST + '/article/info',
                params: { hash: $hash }
            })

            .success(function(data, status, headers, config){
                console.log('Group GET Success - ' + status);
                formatArticleInfo(data);
            })

            .error(function(data, status, headers, config){
                console.log('Group GET Error - ' + status);
                reject(data);
            });
        });
    };

    function getArticleDetail($hash) {
        return $q(function(resolve, reject) {    
            $http({
                method: 'GET',
                url: 'http://' + window.SERVER_HOST + '/article/detail',
                params: { hash: $hash }
            })

            .success(function(data, status, headers, config){
                console.log('Group GET Success - ' + status);
                $scope.content = data;
            })

            .error(function(data, status, headers, config){
                console.log('Group GET Error - ' + status);
                reject(data);
            });
        });
    };
    
    getArticleInfo($hash);
    getArticleDetail($hash);


    // Create the login modal that we will use later
    $ionicModal.fromTemplateUrl('templates/group_send.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal = modal;
    });
    $ionicModal.fromTemplateUrl('templates/info.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal_info = modal;
    });
    // Triggered in the login modal to close it
    $scope.closeLogin = function() {
        $scope.modal.hide();
    };
    $scope.selectGroup = function() {
        $scope.modal.show();
    };
    // Triggered in the login modal to close it
    $scope.closeLoginInfo = function() {
        $scope.modal_info.hide();
    };
    $scope.selectGroupInfo = function() {
        $scope.modal_info.show();
    };

});

opnew.controller('Help', function($scope) {});
opnew.controller('List', function($scope, $http, $q) {

    var now = new Date();
    var year = now.getFullYear();
    var month = now.getMonth()+1;
    var day = now.getDate();
    var $today = now.toISOString().slice(0,10).replace(/-/g,"");
    $scope.date = year + "年" + month + "月" + day + "日";
    
    if (localStorage.sort) {
      var $sort = localStorage.sort;
      $scope.sortName = localStorage.sortName;
    } else {
      var $sort = "new";
      localStorage.sort = "new";
      localStorage.sortName = "新着";
      $scope.sortName = "新着";
    }

    function formatArticleList(data) {
        for (var i in data) {
            $hash = data[i]["hash"];
            data[i]["image"] = 'http://' + window.SERVER_HOST + '/image/' + $today + '/' + $hash + '.jpg';
            data[i]["tag"] = '';
            data[i]["title"] = unescape(data[i]["title"].split("\\").join("%"));
        }
        return data;
    }

    function getArticleList() {
        return $q(function(resolve, reject) {    
            $http({
                method: 'GET',
                url: 'http://' + window.SERVER_HOST + '/article/list',
                params: { sort: $sort }
            })

            .success(function(data, status, headers, config){
                console.log('Group GET Success - ' + status);
                data = formatArticleList(data);
                resolve(data);
            })

            .error(function(data, status, headers, config){
                console.log('Group GET Error - ' + status);
                reject(data);
            });
        });
    };


    var promise_article_list = getArticleList();
    promise_article_list.then(function(data) {
       $scope.playlists = data;
    }, function() {});

});
opnew.controller('Login', ['$scope', '$http', function($scope, $http) {
    $scope.login = function() {}
}]);
opnew.controller('Logout', ['$scope', '$http', function($scope, $http) {
    $scope.logout = function() {
        if (!window.cordova) {
            window.location.href = 'index.html';
        } else {
            var revokeUrl = 'https://accounts.google.com/o/oauth2/revoke?token=' + localStorage.accessToken;
            $http({
                    method: 'GET',
                    url: revokeUrl,
                    async: false,
                    contentType: "application/json",
                    dataType: 'jsonp'
                })
                .success(function(data, status, headers, config) {
                    accessToken = null;
                    localStorage.gmailLogin = "";
                    localStorage.gmailID = "";
                    localStorage.gmailEmail = "";
                    localStorage.gmailFirstName = "";
                    localStorage.gmailLastName = "";
                    localStorage.gmailProfilePicture = "";
                    localStorage.gmailGender = "";
                    localStorage.accessToken = "";
                    window.location.href = 'index.html';
                })
                .error(function(data, status, headers, config) {

                });
        }
    }
}]);

opnew.controller('Receive', function($scope) {
    var $sort = localStorage.sort;
    $scope.playlists = [{
        image: './img/time.jpg',
        title: '新着',
        id: 'new',
        select: ('new' == $sort)
    }, {
        image: './img/view.jpg',
        title: '閲覧数',
        id: 'view',
        select: ('view' == $sort)
    }, {
        image: './img/like.jpg',
        title: 'いいね数',
        id: 'like',
        select: ('like' == $sort)
    }, {
        image: './img/share.jpg',
        title: 'おすすめ数',
        id: 'share',
        select: ('share' == $sort)
    }];
    $scope.selectSort = function(sort, name){
        localStorage.sort = sort;
        localStorage.sortName = name;
        location.reload();
    };
});

opnew.controller('Send', function($scope) {
    $scope.playlists = [{
        image: './img/like.jpg',
        title: 'いいね',
        tag: '',
        id: 1
    }, {
        image: './img/share.jpg',
        title: 'おすすめ',
        tag: '',
        id: 2
    }, {
        image: './img/java.jpg',
        title: 'Java',
        tag: '',
        id: 3
    }, {
        image: './img/html5.png',
        title: 'HTML5',
        tag: '',
        id: 4
    }, {
        image: './img/js.png',
        title: 'JavaScript',
        tag: '',
        id: 5
    }, {
        image: './img/aws.png',
        title: 'AWS',
        tag: '',
        id: 6
    }, {
        image: 'https://s-media-cache-ak0.pinimg.com/736x/39/b4/bc/39b4bc256120b944aea0de96cd418a54.jpg',
        title: '設定',
        tag: '',
        id: 7
    }, {
        image: 'https://c2.staticflickr.com/9/8701/17365015225_282645be84_n.jpg',
        title: 'アプリケーション',
        tag: '',
        id: 8
    }/*, {
        image: 'http://images.apple.com/v/osx/f/images/overview/hero_large_2x.jpg',
        title: 'OS',
        tag: '',
        id: 9
    }*/];
});

opnew.controller('Setting', function($scope, $ionicModal, $stateParams, $http, $q) {

    function getGroup($category) {
        return $q(function(resolve, reject) {    
            $http({
                method: 'GET',
                url: 'http://' + window.SERVER_HOST + '/group/list',
                params: { category: $category }
            })

            .success(function(data, status, headers, config){
                console.log('Group GET Success - ' + status);
                resolve(data);
            })

            .error(function(data, status, headers, config){
                console.log('Group GET Error - ' + status);
                reject(data);
            });
        });
    };

    if (localStorage.gmailEmail == null) {
      profileImage = "https://s.ytimg.com/yts/img/avatar_720-vflYJnzBZ.png";
      profileEmail = "ps_monaca@opst.co.jp";
    } else {
      profileImage = localStorage.gmailProfilePicture;
      profileEmail = localStorage.gmailEmail;
    }
    
    $scope.images = [{ title: profileImage, id: 1 }];
    $scope.emails = [{ title: profileEmail, id: 1 }];
    
    var promise_division = getGroup('division');
    promise_division.then(function(data) {
        $scope.divisions = data;
    }, function() {});

    var promise_affiliation = getGroup('affiliation');
    promise_affiliation.then(function(data) {
        $scope.affiliations = data;
    }, function() {});
    
    var promise_department = getGroup('department');
    promise_department.then(function(data) {
        $scope.departments = data;
    }, function() {});

    // Create the login modal that we will use later
    $ionicModal.fromTemplateUrl('templates/group.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal = modal;
    });
    // Triggered in the login modal to close it
    $scope.closeLogin = function() {
        $scope.modal.hide();
    };
    $scope.selectGroup = function() {
        $scope.modal.show();
    };
});

opnew.controller('StafflistCtrl', function($scope, $ionicModal, $stateParams) {

    // Create the login modal that we will use later
    $ionicModal.fromTemplateUrl('templates/group_send.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal = modal;
    });
    // Triggered in the login modal to close it
    $scope.closeLogin = function() {
        $scope.modal.hide();
    };
    $scope.selectGroup = function() {
        $scope.modal.show();
    };

});
