# monaca

|コマンド|概要|
|:-|:-|
|monaca preview|ローカル上のブラウザでプレビューを表示|


# gulp command

|コマンド|概要|
|:-|:-|
|gulp js|javascriptファイルをコンパイル|
|gulp sass|sassファイルをコンパイル|
|gulp monaca:watch|assets配下のjs,sassフィアルを監視し、自動コンパイルを行う|

# assets構成

## Javascript
|編集PATH|出力PATH|用途|
|:-|:-|:-|
|/assets/controllers|/www/js/controllers.js|コントローラー|
|/assets/filters|/www/js/filters.js|カスタムフィルター|
|/assets/libs|/www/js/libs.js|サードパーティ|
|/assets/models|/www/js/models.js|モデル|
|/assets/utils|/www/js/utils.js|共通処理|

## CSS(SASS)
|編集PATH|出力PATH|用途|
|:-|:-|:-|
|/assets/sass/app.sass|メインsass|www環境でコンパイルされるファイル|

##
