opnew.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider
  .state('app', {
    url: '/app',
    abstract: true,
    templateUrl: 'templates/menu.html',
    controller: 'AppCtrl'
  })

  .state('app.search', {
    url: '/search',
    views: {
      'menuContent': {
        templateUrl: 'templates/search.html'
      }
    }
  })

    .state('app.list', {
      url: '/list',
      views: {
        'menuContent': {
          templateUrl: 'templates/list.html',
          controller: 'List'
        }
      }
    })

    .state('app.receive', {
      url: '/receive',
      views: {
        'menuContent': {
          templateUrl: 'templates/receive.html',
          controller: 'Receive'
        }
      }
    })

    .state('app.send', {
      url: '/send',
      views: {
        'menuContent': {
          templateUrl: 'templates/send.html',
          controller: 'Send'
        }
      }
    })

  .state('app.single', {
    url: '/article/:id',
    views: {
      'menuContent': {
        templateUrl: 'templates/article.html',
        controller: 'ArticleCtrl'
      }
    }
  })

  .state('app.staff', {
    url: '/staff/:groupId',
    views: {
      'menuContent': {
        templateUrl: 'templates/stafflist.html',
        controller: 'StafflistCtrl'
      }
    }
  })

  .state('app.setting', {
    url: '/setting',
    views: {
      'menuContent': {
        templateUrl: 'templates/setting.html',
        controller: 'Setting'
      }
    }
  })
  
  .state('app.help', {
    url: '/help',
    views: {
      'menuContent': {
        templateUrl: 'templates/help.html',
        controller: 'Help'
      }
    }
  });

  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/app/list');
});
