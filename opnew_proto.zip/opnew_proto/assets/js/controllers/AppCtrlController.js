opnew.controller('AppCtrl', function($scope, $ionicModal, $timeout, $http) {
    var $head = document.getElementsByTagName("head")[0];

    if (!window.cordova) {
        window.SERVER_HOST = "ec2-52-198-245-192.ap-northeast-1.compute.amazonaws.com"; // AWSサーバー(臨時)
        var $body = document.getElementsByTagName("body")[0];
        var $title = document.getElementsByTagName("title")[0];
        var $oauth = document.getElementById("oauth");
        var $oauthWrap = document.getElementById("oauth_wrap");
        
        var $metaScope = document.createElement("meta");
        $metaScope.name = "google-signin-scope";
        $metaScope.content = "profile email";
        
        var $metaClientId = document.createElement("meta");
        $metaClientId.name = "google-signin-client_id";
        $metaClientId.content = "632080702527-je7htc0n344nohgdbjrqdnu71ldgoggc.apps.googleusercontent.com";
        
        var $scriptPlatform = document.createElement("script");
        $scriptPlatform.src = "https://apis.google.com/js/platform.js";
        
        var $scriptOnSignIn = document.createElement("script");
        $scriptOnSignIn.src = "js/oauth.js";
        
        var $oauthBtn = document.createElement("div");
        
        $oauth.removeAttribute("ng-click");
        $oauthBtn.id = "oauth_btn";
        $oauthBtn.classList.add("g-signin2");
        $oauthBtn.setAttribute("data-onsuccess", "onSignIn");
        $oauthBtn.setAttribute("data-theme", "dark");
        
        $oauthWrap.appendChild($oauthBtn);
        $head.insertBefore($metaScope, $title);
        $head.insertBefore($metaClientId, $title);
        $head.appendChild($scriptPlatform);
        $body.appendChild($scriptOnSignIn);
    } else {
        window.SERVER_HOST = "ec2-52-198-245-192.ap-northeast-1.compute.amazonaws.com"; // AWSサーバー(臨時)
        var $scriptJquery = document.createElement("script");
        $scriptJquery.src = "lib/jquery.min.js";
        $head.appendChild($scriptJquery);
        var $scriptLogin = document.createElement("script");
        $scriptLogin.src = "js/mobile_oauth.js";
        $head.appendChild($scriptLogin);
    }
});
