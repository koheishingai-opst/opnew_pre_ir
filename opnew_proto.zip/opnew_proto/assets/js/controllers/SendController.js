opnew.controller('Send', function($scope) {
    $scope.playlists = [{
        image: './img/like.jpg',
        title: 'いいね',
        tag: '',
        id: 1
    }, {
        image: './img/share.jpg',
        title: 'おすすめ',
        tag: '',
        id: 2
    }, {
        image: './img/java.jpg',
        title: 'Java',
        tag: '',
        id: 3
    }, {
        image: './img/html5.png',
        title: 'HTML5',
        tag: '',
        id: 4
    }, {
        image: './img/js.png',
        title: 'JavaScript',
        tag: '',
        id: 5
    }, {
        image: './img/aws.png',
        title: 'AWS',
        tag: '',
        id: 6
    }, {
        image: 'https://s-media-cache-ak0.pinimg.com/736x/39/b4/bc/39b4bc256120b944aea0de96cd418a54.jpg',
        title: '設定',
        tag: '',
        id: 7
    }, {
        image: 'https://c2.staticflickr.com/9/8701/17365015225_282645be84_n.jpg',
        title: 'アプリケーション',
        tag: '',
        id: 8
    }/*, {
        image: 'http://images.apple.com/v/osx/f/images/overview/hero_large_2x.jpg',
        title: 'OS',
        tag: '',
        id: 9
    }*/];
});
