opnew.controller('Receive', function($scope) {
    var $sort = localStorage.sort;
    $scope.playlists = [{
        image: './img/time.jpg',
        title: '新着',
        id: 'new',
        select: ('new' == $sort)
    }, {
        image: './img/view.jpg',
        title: '閲覧数',
        id: 'view',
        select: ('view' == $sort)
    }, {
        image: './img/like.jpg',
        title: 'いいね数',
        id: 'like',
        select: ('like' == $sort)
    }, {
        image: './img/share.jpg',
        title: 'おすすめ数',
        id: 'share',
        select: ('share' == $sort)
    }];
    $scope.selectSort = function(sort, name){
        localStorage.sort = sort;
        localStorage.sortName = name;
        location.reload();
    };
});
