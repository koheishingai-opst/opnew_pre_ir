opnew.controller('Login', ['$scope', '$http', function($scope, $http) {
    $scope.login = function() {}
}]);