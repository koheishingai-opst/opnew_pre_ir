opnew.controller('List', function($scope, $http, $q) {

    var now = new Date();
    var year = now.getFullYear();
    var month = now.getMonth()+1;
    var day = now.getDate();
    var $today = now.toISOString().slice(0,10).replace(/-/g,"");
    $scope.date = year + "年" + month + "月" + day + "日";
    
    if (localStorage.sort) {
      var $sort = localStorage.sort;
      $scope.sortName = localStorage.sortName;
    } else {
      var $sort = "new";
      localStorage.sort = "new";
      localStorage.sortName = "新着";
      $scope.sortName = "新着";
    }

    function formatArticleList(data) {
        for (var i in data) {
            $hash = data[i]["hash"];
            data[i]["image"] = 'http://' + window.SERVER_HOST + '/image/' + $today + '/' + $hash + '.jpg';
            data[i]["tag"] = '';
            data[i]["title"] = unescape(data[i]["title"].split("\\").join("%"));
        }
        return data;
    }

    function getArticleList() {
        return $q(function(resolve, reject) {    
            $http({
                method: 'GET',
                url: 'http://' + window.SERVER_HOST + '/article/list',
                params: { sort: $sort }
            })

            .success(function(data, status, headers, config){
                console.log('Group GET Success - ' + status);
                data = formatArticleList(data);
                resolve(data);
            })

            .error(function(data, status, headers, config){
                console.log('Group GET Error - ' + status);
                reject(data);
            });
        });
    };


    var promise_article_list = getArticleList();
    promise_article_list.then(function(data) {
       $scope.playlists = data;
    }, function() {});

});