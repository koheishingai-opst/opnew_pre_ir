opnew.controller('Logout', ['$scope', '$http', function($scope, $http) {
    $scope.logout = function() {
        if (!window.cordova) {
            window.location.href = 'index.html';
        } else {
            var revokeUrl = 'https://accounts.google.com/o/oauth2/revoke?token=' + localStorage.accessToken;
            $http({
                    method: 'GET',
                    url: revokeUrl,
                    async: false,
                    contentType: "application/json",
                    dataType: 'jsonp'
                })
                .success(function(data, status, headers, config) {
                    accessToken = null;
                    localStorage.gmailLogin = "";
                    localStorage.gmailID = "";
                    localStorage.gmailEmail = "";
                    localStorage.gmailFirstName = "";
                    localStorage.gmailLastName = "";
                    localStorage.gmailProfilePicture = "";
                    localStorage.gmailGender = "";
                    localStorage.accessToken = "";
                    window.location.href = 'index.html';
                })
                .error(function(data, status, headers, config) {

                });
        }
    }
}]);
