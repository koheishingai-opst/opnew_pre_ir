opnew.controller('StafflistCtrl', function($scope, $ionicModal, $stateParams) {

    // Create the login modal that we will use later
    $ionicModal.fromTemplateUrl('templates/group_send.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal = modal;
    });
    // Triggered in the login modal to close it
    $scope.closeLogin = function() {
        $scope.modal.hide();
    };
    $scope.selectGroup = function() {
        $scope.modal.show();
    };

});
