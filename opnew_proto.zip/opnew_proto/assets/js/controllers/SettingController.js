opnew.controller('Setting', function($scope, $ionicModal, $stateParams, $http, $q) {

    function getGroup($category) {
        return $q(function(resolve, reject) {    
            $http({
                method: 'GET',
                url: 'http://' + window.SERVER_HOST + '/group/list',
                params: { category: $category }
            })

            .success(function(data, status, headers, config){
                console.log('Group GET Success - ' + status);
                resolve(data);
            })

            .error(function(data, status, headers, config){
                console.log('Group GET Error - ' + status);
                reject(data);
            });
        });
    };

    if (localStorage.gmailEmail == null) {
      profileImage = "https://s.ytimg.com/yts/img/avatar_720-vflYJnzBZ.png";
      profileEmail = "ps_monaca@opst.co.jp";
    } else {
      profileImage = localStorage.gmailProfilePicture;
      profileEmail = localStorage.gmailEmail;
    }
    
    $scope.images = [{ title: profileImage, id: 1 }];
    $scope.emails = [{ title: profileEmail, id: 1 }];
    
    var promise_division = getGroup('division');
    promise_division.then(function(data) {
        $scope.divisions = data;
    }, function() {});

    var promise_affiliation = getGroup('affiliation');
    promise_affiliation.then(function(data) {
        $scope.affiliations = data;
    }, function() {});
    
    var promise_department = getGroup('department');
    promise_department.then(function(data) {
        $scope.departments = data;
    }, function() {});

    // Create the login modal that we will use later
    $ionicModal.fromTemplateUrl('templates/group.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal = modal;
    });
    // Triggered in the login modal to close it
    $scope.closeLogin = function() {
        $scope.modal.hide();
    };
    $scope.selectGroup = function() {
        $scope.modal.show();
    };
});
