opnew.controller('ArticleCtrl', function($scope, $ionicModal, $stateParams, $q, $http) {

    var $hash = $stateParams.id;
    var now = new Date();
    var $today = now.toISOString().slice(0,10).replace(/-/g,"");

    function formatArticleInfo(data) {
        for (var i in data) {
            var date = parseInt(data[i]["date"]);
            date = new Date(date / 10000, date % 10000 / 100, date % 100);
            var year = date.getFullYear();
            var month = date.getMonth();
            var day = date.getDate();
            $scope.date = year + "年" + month + "月" + day + "日"; 
            $scope.tag = '';
            $scope.title = unescape(data[i]["title"].split("\\").join("%"));
        }
    }

    function getArticleInfo($hash) {
        return $q(function(resolve, reject) {    
            $http({
                method: 'GET',
                url: 'http://' + window.SERVER_HOST + '/article/info',
                params: { hash: $hash }
            })

            .success(function(data, status, headers, config){
                console.log('Group GET Success - ' + status);
                formatArticleInfo(data);
            })

            .error(function(data, status, headers, config){
                console.log('Group GET Error - ' + status);
                reject(data);
            });
        });
    };

    function getArticleDetail($hash) {
        return $q(function(resolve, reject) {    
            $http({
                method: 'GET',
                url: 'http://' + window.SERVER_HOST + '/article/detail',
                params: { hash: $hash }
            })

            .success(function(data, status, headers, config){
                console.log('Group GET Success - ' + status);
                $scope.content = data;
            })

            .error(function(data, status, headers, config){
                console.log('Group GET Error - ' + status);
                reject(data);
            });
        });
    };
    
    getArticleInfo($hash);
    getArticleDetail($hash);


    // Create the login modal that we will use later
    $ionicModal.fromTemplateUrl('templates/group_send.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal = modal;
    });
    $ionicModal.fromTemplateUrl('templates/info.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal_info = modal;
    });
    // Triggered in the login modal to close it
    $scope.closeLogin = function() {
        $scope.modal.hide();
    };
    $scope.selectGroup = function() {
        $scope.modal.show();
    };
    // Triggered in the login modal to close it
    $scope.closeLoginInfo = function() {
        $scope.modal_info.hide();
    };
    $scope.selectGroupInfo = function() {
        $scope.modal_info.show();
    };

});
